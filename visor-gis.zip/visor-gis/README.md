# Visor GIS — Luján de Cuyo

Aplicación web (HTML/JS + Leaflet) para visualizar y consultar las 6 capas
municipales: **distritos, zonificación, red vial, loteos, comercios y
parcelario**.

## Cómo correrla

Los navegadores bloquean `fetch()` sobre archivos abiertos con `file://`,
así que hay que servir la carpeta con un servidor local (no requiere
instalación, ya viene con Python):

```bash
cd visor-gis
python3 -m http.server 8000
```

Después abrí `http://localhost:8000` en el navegador. También podés subir
esta carpeta tal cual a cualquier hosting estático (Netlify, GitHub Pages,
un servidor propio, etc.) — no hay backend, todo corre en el navegador.

## Qué incluye

- **index.html / style.css / app.js** — la aplicación.
- **data/** — las 6 capas ya convertidas a WGS84 (lat/lon), listas para
  usar en el navegador (los archivos originales estaban en EPSG:22172,
  Gauss-Krüger faja 2 / Campo Inchauspe).

| Capa | Archivo | Notas |
|---|---|---|
| Distritos | `data/distritos.json` | 15 distritos, siempre visible por defecto |
| Zonificación | `data/zonificacion.json` | coloreada por zona |
| Red vial | `data/red_vial.json` | 9.056 tramos de calle |
| Loteos | `data/loteos.json` | 746 loteos/barrios con geometría válida |
| Comercios | `data/comercios.json` | 5.633 comercios con coordenadas (de 7.361 padrones totales; el resto no tenía ubicación cargada) |
| Parcelario | `data/parcelario_index.ndjson` + `data/parcelario/*.ndjson` | ver abajo |

### Por qué el parcelario está separado

El parcelario original pesa **178 MB** (69.106 parcelas) — imposible de
cargar entero en un navegador de forma razonable. Se lo dividió en dos
piezas:

1. `parcelario_index.ndjson` (15 MB): un índice liviano de **todas** las
   parcelas (padrón, nomenclatura, calle, distrito, lat/lon) que se carga
   entero al iniciar y permite buscar cualquier padrón al instante.
2. `data/parcelario/<distrito>.ndjson`: la geometría completa de cada
   parcela, separada por distrito (entre 176 KB y 8 MB cada una). Se
   cargan **bajo demanda**: al buscar un padrón puntual, o al elegir un
   distrito en el selector "Cargar parcelario completo de un distrito".

## Funcionalidad

- **Buscador** por padrón municipal, nombre de calle, nombre de loteo,
  zonificación (código/zona) o padrón comercial, con filtros por tipo.
  Al hacer clic en un resultado, el mapa hace zoom y abre el popup de esa
  entidad.
- **Clic en cualquier elemento del mapa** abre un popup con todos sus
  atributos relevantes.
- **Panel de capas** para prender/apagar cada dataset.

## Precisión de la reproyección

Los datos originales venían en EPSG:22172. Como el entorno de conversión
no tenía acceso a librerías de proyección (pyproj/GDAL) ni a internet, la
transformación a WGS84 se implementó a mano (fórmulas de Transverse
Mercator + corrección de datum) y se calibró y validó contra 5.633 puntos
del propio dataset de comercios que ya traían lat/lon de referencia. El
error resultante fue de **~0.2 m en longitud y ~0.2 m en latitud (desvío
estándar)** — más que suficiente para uso de visualización municipal,
pero si necesitás precisión catastral/legal, valdría la pena
re-verificarlo con una librería de proyección oficial (pyproj) contra el
dato fuente.

## Limitaciones conocidas / posibles mejoras

- El parcelario cargado por distrito no tiene botón para "descargarlo" de
  memoria una vez cargado (solo se puede ocultar con el layer si se
  agrega ese control).
- La búsqueda de calles agrupa tramos por nombre exacto; variaciones de
  escritura no se normalizan más allá de mayúsculas/acentos.
- Los 41 comercios y 45 parcelas sin coordenadas cargadas no aparecen en
  el mapa (dato faltante en el origen).

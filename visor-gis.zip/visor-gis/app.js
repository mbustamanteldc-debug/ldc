/* ============================================================
   GIS Luján de Cuyo — visor municipal
   ============================================================ */

const DATA = "data/";

const map = L.map("map", { zoomControl: false, preferCanvas: true }).setView([-33.05, -68.86], 12);
L.control.zoom({ position: "topright" }).addTo(map);

L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
  attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
  subdomains: "abcd",
  maxZoom: 20,
}).addTo(map);

const toast = document.getElementById("loadToast");
function showToast(msg, ms = 2200) {
  toast.textContent = msg;
  toast.style.display = "block";
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => (toast.style.display = "none"), ms);
}

function normalize(s) {
  if (s === null || s === undefined) return "";
  return String(s)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

/* ------------------------------------------------------------
   Generic popup builder
------------------------------------------------------------ */
function popupHTML(title, rows) {
  let html = `<div class="popup-title">${title}</div><table class="popup-table">`;
  for (const [k, v] of rows) {
    if (v === null || v === undefined || v === "" || v === "None") continue;
    html += `<tr><td class="k">${k}</td><td class="v">${v}</td></tr>`;
  }
  html += "</table>";
  return html;
}

const LABELS = {
  distritos: { distrito: "Distrito", poblacion: "Población", superficie: "Superficie (m²)" },
  zonificacion: {
    zona_: "Zona", codigo: "Código", lote_min: "Lote mínimo (m²)", lado_min: "Lado mínimo (m)",
    fos: "F.O.S.", retiro_fro: "Retiro frontal (m)", retiro_lat: "Retiro lateral (m)",
    retiro_pos: "Retiro posterior (m)", alt_max: "Altura máx.", altura_maxima: "Altura máx.",
    ordenanza: "Ordenanza", sup_m2: "Superficie (m²)", codm: "Cód. municipal",
  },
  red_vial: {
    nombre: "Calle", tipo: "Tipo", jerarquia: "Jerarquía", categoria: "Categoría",
    material: "Material", barrios: "Barrio(s)", distrito: "Distrito", n_ruta: "N° de ruta",
  },
  loteos: {
    nom_barrio: "Loteo / Barrio", codigo: "Código", tipo: "Tipo", caracteris: "Características",
    distritos: "Distrito(s)", referente: "Referente", ordenanza: "Ordenanza", decreto: "Decreto",
    cant_const: "Cant. construcciones", cantidad_parce: "Cant. parcelas", AREA: "Área (m²)",
  },
  comercios: {
    padron: "Padrón comercial", nombre: "Nombre fantasía", calle: "Calle", altura: "Altura",
    localidad: "Localidad", rubro: "Rubro", descripcion: "Descripción", telefono: "Teléfono",
    distrito: "Distrito", departamento: "Departamento", padron_inmueble: "Padrón inmueble",
  },
  parcelario: {
    nomenclatu: "Nomenclatura", padronmuni: "Padrón municipal", CallePadro: "Calle",
    AlturaPadr: "Altura", Barrio: "Barrio", LocalidadP: "Localidad", ManzanaPad: "Manzana",
    LotePadron: "Lote", FraccionPa: "Fracción", Zonificaci: "Zonificación",
    SupTotal: "Superficie total (m²)", distrito: "Distrito",
  },
};

function rowsFor(layerKey, props) {
  const labels = LABELS[layerKey] || {};
  const keys = Object.keys(labels);
  return keys.map((k) => [labels[k], props[k]]);
}

function titleFor(layerKey, props) {
  switch (layerKey) {
    case "distritos": return props.distrito || "Distrito";
    case "zonificacion": return "Zona " + (props.zona_ || props.codigo || "");
    case "red_vial": return props.nombre || "Calle sin nombre";
    case "loteos": return props.nom_barrio || "Loteo";
    case "comercios": return props.nombre || ("Comercio padrón " + props.padron);
    case "parcelario": return "Padrón " + (props.padronmuni || "s/d");
    default: return "";
  }
}

function bindGenericPopup(feature, layer, layerKey) {
  const p = feature.properties || {};
  layer.bindPopup(popupHTML(titleFor(layerKey, p), rowsFor(layerKey, p)));
}

/* ------------------------------------------------------------
   Color helpers
------------------------------------------------------------ */
const PALETTE = ["#c98a3e", "#6f9c76", "#7a9bc9", "#c0654f", "#a37fc9", "#c9b23e", "#4fa8a0", "#c96f95"];
const colorCache = {};
function colorFor(key) {
  if (!(key in colorCache)) {
    const idx = Object.keys(colorCache).length % PALETTE.length;
    colorCache[key] = PALETTE[idx];
  }
  return colorCache[key];
}

/* ------------------------------------------------------------
   Layer registry
------------------------------------------------------------ */
const layers = {}; // key -> { leafletLayer, data, visible }
const layerGroup = {};

function addLayerToggleRow(key, label, colorSwatch, countLabel) {
  const wrap = document.getElementById("layerList");
  const row = document.createElement("div");
  row.className = "layer-row";
  row.innerHTML = `
    <input type="checkbox" id="chk_${key}">
    <span class="swatch" style="background:${colorSwatch}"></span>
    <label for="chk_${key}">${label}</label>
    <span class="count">${countLabel || ""}</span>`;
  wrap.appendChild(row);
  const chk = row.querySelector("input");
  chk.addEventListener("change", () => {
    if (chk.checked) {
      map.addLayer(layerGroup[key]);
    } else {
      map.removeLayer(layerGroup[key]);
    }
  });
  return chk;
}

/* ------------------------------------------------------------
   Fetch helpers
------------------------------------------------------------ */
async function fetchJSON(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error("No se pudo cargar " + path);
  return res.json();
}
async function fetchNDJSON(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error("No se pudo cargar " + path);
  const text = await res.text();
  const out = [];
  for (const line of text.split("\n")) {
    const t = line.trim();
    if (!t) continue;
    try { out.push(JSON.parse(t)); } catch (e) {}
  }
  return out;
}

/* ============================================================
   Load layers
============================================================ */
let distritosData, zonificacionData, redVialData, loteosData, comerciosData;
let parcelarioIndex = [];
const parcelarioDistritoCache = {}; // slug -> leaflet layer

(async function init() {
  showToast("Cargando capas base…", 60000);

  // ---- distritos ----
  distritosData = await fetchJSON(DATA + "distritos.json");
  const distritosLayer = L.geoJSON(distritosData, {
    style: { color: "#eef2ef", weight: 1.4, fillOpacity: 0.02, dashArray: "4,3" },
    onEachFeature: (f, l) => {
      bindGenericPopup(f, l, "distritos");
      l.bindTooltip(f.properties.distrito, { permanent: true, direction: "center", className: "distrito-label" });
    },
  });
  layerGroup.distritos = distritosLayer;
  addLayerToggleRow("distritos", "Distritos", "#eef2ef", distritosData.features.length).checked = true;
  map.addLayer(distritosLayer);
  populateDistritoPicker(distritosData.features.map((f) => f.properties.distrito).sort());

  // ---- zonificacion ----
  zonificacionData = await fetchJSON(DATA + "zonificacion.json");
  const zonificacionLayer = L.geoJSON(zonificacionData, {
    style: (f) => ({ color: colorFor(f.properties.zona_ || f.properties.codigo), weight: 1, fillOpacity: 0.25 }),
    onEachFeature: (f, l) => bindGenericPopup(f, l, "zonificacion"),
  });
  layerGroup.zonificacion = zonificacionLayer;
  addLayerToggleRow("zonificacion", "Zonificación", "#c98a3e", zonificacionData.features.length);

  // ---- red vial ----
  redVialData = await fetchJSON(DATA + "red_vial.json");
  const redVialLayer = L.geoJSON(redVialData, {
    style: { color: "#7a9bc9", weight: 1.6, opacity: 0.85 },
    onEachFeature: (f, l) => bindGenericPopup(f, l, "red_vial"),
  });
  layerGroup.red_vial = redVialLayer;
  addLayerToggleRow("red_vial", "Red vial", "#7a9bc9", redVialData.features.length);

  // ---- loteos ----
  loteosData = await fetchJSON(DATA + "loteos.json");
  const loteosLayer = L.geoJSON(loteosData, {
    style: { color: "#c0654f", weight: 1.3, fillOpacity: 0.08 },
    onEachFeature: (f, l) => bindGenericPopup(f, l, "loteos"),
  });
  layerGroup.loteos = loteosLayer;
  addLayerToggleRow("loteos", "Loteos / barrios", "#c0654f", loteosData.features.length);

  // ---- comercios (clustered) ----
  comerciosData = await fetchJSON(DATA + "comercios.json");
  const clusterAvailable = typeof L.markerClusterGroup === "function";
  const comerciosLayer = clusterAvailable ? L.markerClusterGroup({ maxClusterRadius: 45 }) : L.layerGroup();
  comerciosData.features.forEach((f) => {
    const [lon, lat] = f.geometry.coordinates;
    const m = L.circleMarker([lat, lon], {
      radius: 5, color: "#a37fc9", fillColor: "#a37fc9", fillOpacity: 0.85, weight: 1,
    });
    bindGenericPopup(f, m, "comercios");
    comerciosLayer.addLayer(m);
  });
  layerGroup.comercios = comerciosLayer;
  addLayerToggleRow("comercios", "Comercios", "#a37fc9", comerciosData.features.length);

  // ---- parcelario index (search only, lightweight) ----
  parcelarioIndex = await fetchNDJSON(DATA + "parcelario_index.ndjson");
  document.getElementById("parcelCount").textContent = parcelarioIndex.length.toLocaleString("es-AR");

  // empty group placeholder for "parcelario" toggle row status (per-distrito loads add themselves)
  layerGroup.parcelario = L.layerGroup();

  showToast("Capas cargadas ✓", 1600);
})().catch((err) => {
  console.error(err);
  showToast("Error cargando datos: " + err.message, 6000);
});

/* ------------------------------------------------------------
   Distrito picker -> load full parcelario for a distrito
------------------------------------------------------------ */
function populateDistritoPicker(names) {
  const sel = document.getElementById("distritoPicker");
  names.forEach((n) => {
    const opt = document.createElement("option");
    opt.value = n; opt.textContent = n;
    sel.appendChild(opt);
  });
  sel.addEventListener("change", async () => {
    const name = sel.value;
    if (!name) return;
    await loadParcelDistrito(name, true);
  });
}

function slugify(name) {
  return normalize(name).replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
}

async function loadParcelDistrito(distritoName, zoomTo) {
  const slug = slugify(distritoName);
  if (!parcelarioDistritoCache[slug]) {
    showToast("Cargando parcelario de " + distritoName + "…", 15000);
    try {
      const feats = await fetchNDJSON(DATA + `parcelario/${slug}.ndjson`);
      const gj = L.geoJSON(feats, {
        style: { color: "#c9b23e", weight: 0.7, fillOpacity: 0.03 },
        onEachFeature: (f, l) => bindGenericPopup(f, l, "parcelario"),
      });
      parcelarioDistritoCache[slug] = gj;
      showToast(distritoName + ": " + feats.length.toLocaleString("es-AR") + " parcelas cargadas", 2200);
    } catch (e) {
      showToast("No se pudo cargar el parcelario de " + distritoName, 4000);
      return null;
    }
  }
  const gj = parcelarioDistritoCache[slug];
  if (!map.hasLayer(gj)) map.addLayer(gj);
  if (zoomTo) map.fitBounds(gj.getBounds(), { maxZoom: 16 });
  return gj;
}

/* ============================================================
   Search
============================================================ */
let activeTypes = new Set(["padron", "calles", "loteos", "zonif", "comercial"]);

document.querySelectorAll(".chip").forEach((chip) => {
  chip.addEventListener("click", () => {
    const t = chip.dataset.type;
    if (t === "all") {
      activeTypes = new Set(["padron", "calles", "loteos", "zonif", "comercial"]);
      document.querySelectorAll(".chip").forEach((c) => c.classList.toggle("active", c.dataset.type === "all" || activeTypes.has(c.dataset.type)));
      return;
    }
    document.querySelector('.chip[data-type="all"]').classList.remove("active");
    if (activeTypes.has(t)) activeTypes.delete(t); else activeTypes.add(t);
    chip.classList.toggle("active");
    if (activeTypes.size === 0) {
      activeTypes = new Set(["padron", "calles", "loteos", "zonif", "comercial"]);
      document.querySelectorAll(".chip").forEach((c) => c.classList.add("active"));
    }
  });
});

document.getElementById("searchBtn").addEventListener("click", runSearch);
document.getElementById("searchInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter") runSearch();
});

function runSearch() {
  const raw = document.getElementById("searchInput").value.trim();
  const resultsEl = document.getElementById("results");
  resultsEl.innerHTML = "";
  if (raw.length < 2) {
    resultsEl.innerHTML = '<div class="empty-msg">Escribí al menos 2 caracteres para buscar.</div>';
    return;
  }
  const q = normalize(raw);
  const results = [];

  if (activeTypes.has("padron") && parcelarioIndex.length) {
    parcelarioIndex.forEach((r) => {
      if (
        normalize(r.padron).includes(q) ||
        normalize(r.nomenclatu).includes(q) ||
        normalize(r.calle).includes(q)
      ) {
        results.push({
          type: "padron", title: "Padrón " + (r.padron || "s/d"),
          sub: [r.calle, r.altura, r.barrio, r.distrito].filter(Boolean).join(" · "),
          go: () => goToParcel(r),
        });
      }
    });
  }

  if (activeTypes.has("calles") && redVialData) {
    const seen = new Set();
    redVialData.features.forEach((f) => {
      const nombre = f.properties.nombre;
      if (nombre && normalize(nombre).includes(q) && !seen.has(nombre)) {
        seen.add(nombre);
        results.push({
          type: "calles", title: nombre,
          sub: [f.properties.jerarquia, f.properties.barrios].filter(Boolean).join(" · "),
          go: () => goToStreet(nombre),
        });
      }
    });
  }

  if (activeTypes.has("loteos") && loteosData) {
    loteosData.features.forEach((f) => {
      const nombre = f.properties.nom_barrio;
      if (nombre && normalize(nombre).includes(q)) {
        results.push({
          type: "loteos", title: nombre,
          sub: [f.properties.tipo, f.properties.distritos].filter(Boolean).join(" · "),
          go: () => goToFeature(f, "loteos", layerGroup.loteos),
        });
      }
    });
  }

  if (activeTypes.has("zonif") && zonificacionData) {
    zonificacionData.features.forEach((f) => {
      const z = f.properties.zona_ || "";
      const c = f.properties.codigo || "";
      if (normalize(z).includes(q) || normalize(c).includes(q)) {
        results.push({
          type: "zonif", title: "Zona " + (z || c),
          sub: ["FOS " + (f.properties.fos ?? "-"), "Altura máx " + (f.properties.alt_max ?? f.properties.altura_maxima ?? "-")].join(" · "),
          go: () => goToFeature(f, "zonificacion", layerGroup.zonificacion),
        });
      }
    });
  }

  if (activeTypes.has("comercial") && comerciosData) {
    comerciosData.features.forEach((f) => {
      const p = f.properties;
      if (
        normalize(p.padron).includes(q) ||
        normalize(p.nombre).includes(q) ||
        normalize(p.calle).includes(q)
      ) {
        results.push({
          type: "comercial", title: p.nombre || ("Comercio padrón " + p.padron),
          sub: [p.calle, p.altura, p.rubro].filter(Boolean).join(" · "),
          go: () => goToFeature(f, "comercios", layerGroup.comercios, f.geometry.coordinates),
        });
      }
    });
  }

  renderResults(results.slice(0, 80), resultsEl, results.length);
}

const TYPE_LABEL = { padron: "Padrón municipal", calles: "Calle", loteos: "Loteo", zonif: "Zonificación", comercial: "Padrón comercial" };

function renderResults(results, el, total) {
  if (!results.length) {
    el.innerHTML = '<div class="empty-msg">Sin resultados.</div>';
    return;
  }
  el.innerHTML = "";
  results.forEach((r) => {
    const div = document.createElement("div");
    div.className = "result-item";
    div.innerHTML = `<div class="r-title">${r.title}</div>
      <div class="r-sub">${r.sub || ""}</div>
      <span class="r-tag">${TYPE_LABEL[r.type]}</span>`;
    div.addEventListener("click", r.go);
    el.appendChild(div);
  });
  if (total > results.length) {
    const more = document.createElement("div");
    more.className = "empty-msg";
    more.textContent = `Mostrando ${results.length} de ${total} resultados. Afiná la búsqueda para ver más.`;
    el.appendChild(more);
  }
}

async function goToParcel(indexRow) {
  const gj = await loadParcelDistrito(indexRow.distrito, false);
  if (!gj) {
    map.setView([indexRow.lat, indexRow.lon], 18);
    return;
  }
  const chk = document.getElementById("chk_" + slugify(indexRow.distrito));
  let matched = null;
  gj.eachLayer((l) => {
    if (l.feature && l.feature.properties && l.feature.properties.id === indexRow.id) matched = l;
  });
  if (matched) {
    map.fitBounds(matched.getBounds(), { maxZoom: 19 });
    matched.openPopup();
    matched.setStyle && matched.setStyle({ color: "#eef2ef", weight: 2.4 });
    setTimeout(() => matched.setStyle && matched.setStyle({ color: "#c9b23e", weight: 0.7 }), 3500);
  } else {
    map.setView([indexRow.lat, indexRow.lon], 18);
  }
}

function goToStreet(nombre) {
  if (!map.hasLayer(layerGroup.red_vial)) {
    document.getElementById("chk_red_vial").checked = true;
    map.addLayer(layerGroup.red_vial);
  }
  const group = [];
  layerGroup.red_vial.eachLayer((l) => {
    if (l.feature.properties.nombre === nombre) group.push(l);
  });
  if (!group.length) return;
  const fg = L.featureGroup(group);
  map.fitBounds(fg.getBounds(), { maxZoom: 17 });
  group.forEach((l) => l.setStyle({ color: "#eef2ef", weight: 4 }));
  group[0].openPopup();
  setTimeout(() => group.forEach((l) => l.setStyle({ color: "#7a9bc9", weight: 1.6 })), 3500);
}

function goToFeature(feature, layerKey, group, pointCoords) {
  const chk = document.getElementById("chk_" + layerKey);
  if (chk && !chk.checked) { chk.checked = true; map.addLayer(group); }
  let target = null;
  group.eachLayer((l) => {
    if (l.feature === feature) target = l;
  });
  if (!target) return;
  if (typeof group.zoomToShowLayer === "function") {
    // marker cluster group: handles spiderfying / zoom automatically
    group.zoomToShowLayer(target, () => target.openPopup());
    return;
  }
  if (pointCoords) {
    map.setView([pointCoords[1], pointCoords[0]], 18);
  } else if (target.getBounds) {
    map.fitBounds(target.getBounds(), { maxZoom: 18 });
  }
  target.openPopup();
}
